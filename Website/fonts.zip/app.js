var express=require("express");
var app=express();

let {PythonShell} = require('python-shell');
const path = require('path')
const {spawn} = require('child_process')

// /**
//  * Run python script, pass in `-u` to not buffer console output 
//  * @return {ChildProcess}
//  */
// function runScript(){
//   return spawn('py', [
//     "-u", 
//     path.join(__dirname, 'script1.py'),
//     "--foo", "some value for foo",
//   ]);
// }

// const subprocess = runScript()

// // print output of script
// subprocess.stdout.on('data', (data) => {
//   console.log(`data:${data}`);
// });
// subprocess.stderr.on('data', (data) => {
//   console.log(`error:${data}`);
// });
// subprocess.on('close', () => {
//   console.log("Closed");
// });


app.use(express.static(__dirname+"/public"));
app.use(express.static(__dirname+"/fonts"));



app.set("view engine","ejs");


 


app.get("/",function(req,res){
    res.render("index");
});

app.get('/name', callName); 
  
function callName(req, res) { 
      
    // Use child_process.spawn method from  
    // child_process module and assign it 
    // to variable spawn 
    
      
    // Parameters passed in spawn - 
    // 1. type_of_script 
    // 2. list containing Path of the script 
    //    and arguments for the script  
      
    // E.g : http://localhost:3000/name?firstname=Mike&lastname=Will 
    // so, first name = Mike and last name = Will 
    var process = spawn('py',["-u", path.join(__dirname, 'scr.py'), 
                            req.query.firstname, 
                            req.query.lastname] ); 
  
    // Takes stdout data from script which executed 
    // with arguments and send this data to res object 
    process.stdout.on('data', function(data) { 
        res.send(data.toString()); 
    } ) 
} 
  
// save code as start.js 

app.get('/run', function (req, res) {
    const subprocess = runScript()
    res.set('Content-Type', 'text/plain');
    subprocess.stdout.pipe(res)
    subprocess.stderr.pipe(res)
  })

app.get("/upload",function(req,res){
res.render("upload");
});

var port = process.env.PORT || 3000;
app.listen(port, function () {
  console.log("Server Has Started!");
});