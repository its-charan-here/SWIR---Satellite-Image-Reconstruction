import math

def area_of_circle(r):
    a = r**2 * math.pi
    return a

print("enter the radius");
print (area_of_circle(int(input())))
